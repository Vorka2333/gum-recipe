# gum_recipe
Official txAdmin recipe for Gum Framework.


# SETUP

1. Select the option Remote Template URL in TxAdmin.
2. copy and paste this url inside `https://github.com/Gum-Core/gum_recipe/blob/main/gum_framework.yaml`.
3. Click Next and follow next instructions.
4. Enjoy.
